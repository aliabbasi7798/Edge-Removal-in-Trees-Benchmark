from collections import deque
from itertools import combinations
import timeit
import numpy as np


def constrained_mckp_dp_two_budgets(costs_e, costs_v, values, properties, B_e, B_v):
    num_classes = len(costs_e)
    assert len(costs_v) == num_classes and len(values) == num_classes and len(properties) == num_classes

    V0_prev = np.full((B_e + 1, B_v + 1), -np.inf)
    V1_prev = np.full((B_e + 1, B_v + 1), -np.inf)
    V0_curr = np.full((B_e + 1, B_v + 1), -np.inf)
    V1_curr = np.full((B_e + 1, B_v + 1), -np.inf)

    V0_prev[0, 0] = 0.0

    for k in range(num_classes):
        V0_curr.fill(-np.inf)
        V1_curr.fill(-np.inf)

        for j in range(len(costs_e[k])):
            ce = costs_e[k][j]
            cv = costs_v[k][j]
            val = values[k][j]
            is_special = properties[k][j]

            if ce <= B_e and cv <= B_v:
                src0 = V0_prev[:B_e + 1 - ce, :B_v + 1 - cv] + val
                src1 = V1_prev[:B_e + 1 - ce, :B_v + 1 - cv] + val
                tgt_e = slice(ce, B_e + 1)
                tgt_v = slice(cv, B_v + 1)

                if is_special:
                    np.maximum(V1_curr[tgt_e, tgt_v], src0, out=V1_curr[tgt_e, tgt_v])
                    np.maximum(V1_curr[tgt_e, tgt_v], src1, out=V1_curr[tgt_e, tgt_v])
                else:
                    np.maximum(V0_curr[tgt_e, tgt_v], src0, out=V0_curr[tgt_e, tgt_v])
                    np.maximum(V1_curr[tgt_e, tgt_v], src1, out=V1_curr[tgt_e, tgt_v])

        V0_prev, V0_curr = V0_curr, V0_prev
        V1_prev, V1_curr = V1_curr, V1_prev

    return V1_prev


def constrained_mckp_dp_two_budgets_base(costs_e, costs_v, values, properties, B_e, B_v):
    num_classes = len(costs_e)
    assert len(costs_v) == num_classes and len(values) == num_classes and len(properties) == num_classes

    V0 = np.full((num_classes + 1, B_e + 1, B_v + 1), -np.inf)
    V1 = np.full((num_classes + 1, B_e + 1, B_v + 1), -np.inf)
    V0[0, 0, 0] = 0.0

    for k in range(1, num_classes + 1):
        class_idx = k - 1
        for j in range(len(costs_e[class_idx])):
            ce = costs_e[class_idx][j]
            cv = costs_v[class_idx][j]
            val = values[class_idx][j]
            is_special = properties[class_idx][j]

            if ce <= B_e and cv <= B_v:
                src0 = V0[k - 1, :B_e + 1 - ce, :B_v + 1 - cv] + val
                src1 = V1[k - 1, :B_e + 1 - ce, :B_v + 1 - cv] + val
                tgt_e = slice(ce, B_e + 1)
                tgt_v = slice(cv, B_v + 1)

                if is_special:
                    V1[k, tgt_e, tgt_v] = np.maximum(V1[k, tgt_e, tgt_v], src0)
                    V1[k, tgt_e, tgt_v] = np.maximum(V1[k, tgt_e, tgt_v], src1)
                else:
                    V0[k, tgt_e, tgt_v] = np.maximum(V0[k, tgt_e, tgt_v], src0)
                    V1[k, tgt_e, tgt_v] = np.maximum(V1[k, tgt_e, tgt_v], src1)

    return V1[num_classes]

def read_input(data):
    lines = data.strip().split('\n')
    n, B_e, B_v = map(int, lines[0].split())

    node_info = {}
    idx = 1
    for _ in range(n):
        parts = lines[idx].split()
        idx += 1
        u = int(parts[0])
        typ = parts[1]
        if typ == 'f':
            node_info[u] = ('f', 0)
        else:
            w = int(parts[2])
            node_info[u] = ('c', w)

    m = int(lines[idx])
    idx += 1
    edges = []
    for _ in range(m):
        u, v = map(int, lines[idx].split())
        idx += 1
        edges.append((u, v))

    return n, B_e, B_v, node_info, edges


def build_tree(n, edges, root=1):
    # Create the adjacency list.
    adj = [[] for _ in range(n + 1)]
    for u, v in edges:
        adj[u].append(v)
        adj[v].append(u)

    # Initialize parent, children, and height arrays.
    height = [0] * (n + 1)
    parent = [0] * (n + 1)
    children = [[] for _ in range(n + 1)]

    # Set the root's parent to -1 and its height (0 or 1, here we choose 0).
    parent[root] = -1
    height[root] = 0

    q = deque([root])
    visited = [False] * (n + 1)
    visited[root] = True

    while q:
        u = q.popleft()
        for w in adj[u]:
            if not visited[w]:
                visited[w] = True
                parent[w] = u
                # Set the child's height as parent's height + 1.
                height[w] = height[u] + 1
                children[u].append(w)
                q.append(w)
    # print(parent, children)
    return parent, children, height


def dfs(node, children, visited, node_info, d0, d1, d2, budget_e , budget_v):
    visited[node] = True
    for child in children[node]:
        if not visited[child]:
            dfs(child, children, visited, node_info, d0, d1, d2, budget_e , budget_v)
    compute_dp(node, budget_e , budget_v, node_info, children, d0, d1, d2)



def perform_dfs(n, budget_e , budget_v, node_info, edges):
    _, children, _ = build_tree(n, edges, root=1)
    visited = [False] * (n + 1)
    d0, d1, d2= initialize_dp(n, budget_e , budget_v, node_info, children)
    dfs(1, children, visited, node_info, d0, d1, d2, budget_e , budget_v)
    #print(sel)
    #print(d1[1][budget_e][budget_v])
    return max(d0[1][budget_e][budget_v], d1[1][budget_e][budget_v], d2[1][budget_e][budget_v])


def initialize_dp(n, budget_e, budget_v, node_info, children):
    INF = float('-inf')
    d0 = [[[INF] * (budget_v + 1) for _ in range(budget_e + 1)] for _ in range(n + 1)]
    d1 = [[[INF] * (budget_v + 1) for _ in range(budget_e + 1)] for _ in range(n + 1)]
    d2 = [[[INF] * (budget_v + 1) for _ in range(budget_e + 1)] for _ in range(n + 1)]


    return d0, d1, d2


def compute_dp(u, budget_e , budget_v, node_info, children, d0, d1, d2):
    typ, w = node_info[u]
    INF = float('-inf')

    if len(children[u]) == 0:
        for i in range(budget_e + 1):
            for j in range(budget_v + 1):

                if typ == 'f':

                    d0[u][i][j] = INF
                    d1[u][i][j] = 0
                    d2[u][i][j] = INF



                else:

                    d0[u][i][j] = w
                    d1[u][i][j] = INF
                    d2[u][i][j] = 0


        return


    if typ == 'f':
        for i in range(budget_e + 1):
            for j in range(budget_v + 1):
                d0[u][i][j] = INF
                d2[u][i][j] = INF
        child_options_for_d1_f = []
        child_options_for_d1_f_c_e = []
        child_options_for_d1_f_c_v = []
        child_options_for_d1_f_p = []

        for cnode in children[u]:
            arr_v = []
            arr_c_e = []
            arr_c_v = []
            arr_p = []
            for B_v in range(budget_v + 1):


                for B_e in range(budget_e + 1):
                    if B_e >= 1:
                        arr_v.append(max(d2[cnode][B_e][B_v], d1[cnode][B_e][B_v], d0[cnode][B_e-1][B_v]))

                    else:
                        arr_v.append(max(d2[cnode][B_e][B_v], d1[cnode][B_e][B_v]))


                    arr_c_e.append(B_e)
                    arr_c_v.append(B_v)
                    arr_p.append(1)



            # print(arr_v,arr_c,arr_p)
            child_options_for_d1_f.append(arr_v)
            child_options_for_d1_f_c_e.append(arr_c_e)
            child_options_for_d1_f_c_v.append(arr_c_v)
            child_options_for_d1_f_p.append(arr_p)

        # print("hello")
        result = constrained_mckp_dp_two_budgets(child_options_for_d1_f_c_e, child_options_for_d1_f_c_v, child_options_for_d1_f, child_options_for_d1_f_p,budget_e, budget_v)
        #print(result)
        for B_v in range(budget_v + 1):
            for B_e in range(budget_e + 1):

                    d1[u][B_e][B_v] = result[B_e][B_v]



    if typ == 'c':

        child_options_for_d0_f = []
        child_options_for_d0_f_c_e = []
        child_options_for_d0_f_c_v = []
        child_options_for_d0_f_p = []

        child_options_for_d0_f_d = []
        child_options_for_d0_f_c_e_d = []
        child_options_for_d0_f_c_v_d = []
        child_options_for_d0_f_p_d = []

        for cnode in children[u]:
            arr_v = []
            arr_c_e = []
            arr_c_v = []
            arr_p = []
            arr_v_d = []
            arr_c_e_d = []
            arr_c_v_d = []
            arr_p_d = []
            for B_v in range(budget_v + 1):

                for B_e in range(budget_e + 1):
                    if B_e >= 1:
                        arr_v.append(max(d0[cnode][B_e][B_v], d1[cnode][B_e - 1][B_v], d0[cnode][B_e - 1][B_v]))
                        arr_v_d.append(max(d0[cnode][B_e][B_v], d1[cnode][B_e][B_v]))
                    else:
                        arr_v.append(d1[cnode][B_e][B_v])
                        arr_v_d.append(max(d0[cnode][B_e][B_v], d1[cnode][B_e][B_v]))

                    arr_c_e.append(B_e)
                    arr_c_v.append(B_v)
                    arr_p.append(1)

                    arr_c_e_d.append(B_e)
                    arr_c_v_d.append(B_v)
                    arr_p_d.append(1)

                # print(arr_v,arr_c,arr_p)
            child_options_for_d0_f.append(arr_v)
            child_options_for_d0_f_c_e.append(arr_c_e)
            child_options_for_d0_f_c_v.append(arr_c_v)
            child_options_for_d0_f_p.append(arr_p)

            child_options_for_d0_f_d.append(arr_v_d)
            child_options_for_d0_f_c_e_d.append(arr_c_e_d)
            child_options_for_d0_f_c_v_d.append(arr_c_v_d)
            child_options_for_d0_f_p_d.append(arr_p_d)
            #print(child_options_for_d0_f_c_e, child_options_for_d0_f_c_v,
             #                                        child_options_for_d0_f, child_options_for_d0_f_p, B_e, B_v)
        result = constrained_mckp_dp_two_budgets(child_options_for_d0_f_c_e, child_options_for_d0_f_c_v,
                                                     child_options_for_d0_f, child_options_for_d0_f_p,budget_e, budget_v)
        result_d = constrained_mckp_dp_two_budgets(child_options_for_d0_f_c_e_d, child_options_for_d0_f_c_v_d,
                                                       child_options_for_d0_f_d, child_options_for_d0_f_p_d,budget_e, budget_v)
        # print(selr)
        for B_v in range(budget_v + 1):
            for B_e in range(budget_e + 1):
                if B_v >= 1:
                    d0[u][B_e][B_v] = max(result[B_e][B_v], result_d[B_e][B_v - 1]) + w
                else:
                    d0[u][B_e][B_v] = result[B_e][B_v] + w
    if typ == 'c':

        child_options_for_d2_f = []
        child_options_for_d2_f_c_e = []
        child_options_for_d2_f_c_v = []
        child_options_for_d2_f_p = []

        child_options_for_d2_f_d = []
        child_options_for_d2_f_c_e_d = []
        child_options_for_d2_f_c_v_d = []
        child_options_for_d2_f_p_d = []

        for cnode in children[u]:
            arr_v = []
            arr_c_e = []
            arr_c_v = []
            arr_p = []
            arr_v_d = []
            arr_c_e_d = []
            arr_c_v_d = []
            arr_p_d = []
            for B_v in range(budget_v + 1):

                for B_e in range(budget_e + 1):
                    if B_e >= 1:
                        arr_v.append(max(d2[cnode][B_e][B_v], d1[cnode][B_e - 1][B_v], d0[cnode][B_e - 1][B_v]))
                        arr_v_d.append(max(d0[cnode][B_e][B_v], d1[cnode][B_e][B_v]))
                    else:
                        arr_v.append(d2[cnode][B_e][B_v])
                        arr_v_d.append(max(d0[cnode][B_e][B_v], d1[cnode][B_e][B_v]))

                    arr_c_e.append(B_e)
                    arr_c_v.append(B_v)
                    arr_p.append(1)

                    arr_c_e_d.append(B_e)
                    arr_c_v_d.append(B_v)
                    arr_p_d.append(1)

                # print(arr_v,arr_c,arr_p)
            child_options_for_d2_f.append(arr_v)
            child_options_for_d2_f_c_e.append(arr_c_e)
            child_options_for_d2_f_c_v.append(arr_c_v)
            child_options_for_d2_f_p.append(arr_p)

            child_options_for_d2_f_d.append(arr_v_d)
            child_options_for_d2_f_c_e_d.append(arr_c_e_d)
            child_options_for_d2_f_c_v_d.append(arr_c_v_d)
            child_options_for_d2_f_p_d.append(arr_p_d)
            # print("hello")
        result = constrained_mckp_dp_two_budgets(child_options_for_d2_f_c_e, child_options_for_d2_f_c_v,
                                                     child_options_for_d2_f, child_options_for_d2_f_p, budget_e, budget_v)
        result_d = constrained_mckp_dp_two_budgets(child_options_for_d2_f_c_e_d, child_options_for_d2_f_c_v_d,
                                                                                    child_options_for_d2_f_d, child_options_for_d2_f_p_d, budget_e, budget_v)
        for B_v in range(budget_v + 1):
            for B_e in range(budget_e + 1):
                #print("hello2")
                if B_v >= 1:
                    d2[u][B_e][B_v] = max(result[B_e][B_v], (result_d[B_e][B_v - 1] + w))
                else:
                    d2[u][B_e][B_v] = result[B_e][B_v]


    if typ == 'c':
        child_options_for_d1 = []
        child_options_for_d1_c_e = []
        child_options_for_d1_c_v = []
        child_options_for_d1_p = []
        for cnode in children[u]:
            arr_v = []
            arr_c_e = []
            arr_c_v = []
            arr_p = []
            for B_v in range(budget_v + 1):
                for B_e in range(budget_e + 1):
                    for z in {0, 1}:
                        if z == 0:
                            if (B_e >= 1):
                                arr_v.append(max(d0[cnode][B_e - 1][B_v], d1[cnode][B_e - 1][B_v], d2[cnode][B_e][B_v]))
                            else:
                                arr_v.append(d2[cnode][B_e][B_v])
                        else:
                            arr_v.append(d1[cnode][B_e][B_v])

                        arr_c_e.append(B_e)
                        arr_c_v.append(B_v)
                        arr_p.append(z)
            # print(arr_v,arr_c,arr_p)
            child_options_for_d1.append(arr_v)
            child_options_for_d1_c_e.append(arr_c_e)
            child_options_for_d1_c_v.append(arr_c_v)
            child_options_for_d1_p.append(arr_p)
        #print(child_options_for_d1_c, child_options_for_d1, child_options_for_d1_p, B)
        result= constrained_mckp_dp_two_budgets(child_options_for_d1_c_e,child_options_for_d1_c_v, child_options_for_d1, child_options_for_d1_p, budget_e, budget_v)
        #print(result)

        for B_v in range(budget_v + 1):
            for B_e in range(budget_e + 1):
                #print("hello1")
                d1[u][B_e][B_v] = result[B_e][B_v]




def convert_text_file_to_array(filename):
    with open(filename, "r") as file:
        content = file.read()
    return [block for block in content.strip().split("\n\n") if block.strip()]


def main():

    tree_str = convert_text_file_to_array("old_data/trees_Edge_Node_50Total_1000N_0.5F_E_Integer_BE_100.txt")

    start_time = timeit.default_timer()
    answers = []
    for i in range(len(tree_str)):
        print(i)
        n, budget_e , budget_v, node_info, edges = read_input(tree_str[i])
        parent, children , height = build_tree(n, edges, root=1)
        answers.append(perform_dfs(n, budget_e , budget_v, node_info, edges))

    end_time = timeit.default_timer()
    total_time = end_time - start_time
    with open("previouspaperresults/Result_EN_1000_Test_0.5_opt_E_100.txt", "w") as f:
        for idx, ans in enumerate(answers):
            f.write(f"Answer {idx + 1}: {ans}\n")
        f.write(f"\nTotal run time: {total_time:.4f} seconds\n")


if __name__ == "__main__":
    main()
