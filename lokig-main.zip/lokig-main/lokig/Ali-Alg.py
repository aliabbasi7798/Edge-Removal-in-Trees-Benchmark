import timeit
def read_input(data):

    lines = data.strip().split('\n')
    n, r = map(int, lines[0].split())
    print(r)
    node_info = {}
    idx = 1
    for _ in range(n):
        parts = lines[idx].split()
        idx += 1
        u = int(parts[0])
        typ = parts[1]
        if typ == 'f':
            node_info[u] = ('f', 0)
        else:
            w = int(parts[2])
            node_info[u] = ('c', w)

    m = int(lines[idx]); idx += 1
    edges = []
    for _ in range(m):
        u,v = map(int, lines[idx].split())
        idx += 1
        edges.append((u,v))
    return n, r, node_info, edges


def build_tree(n, edges, root=1):
    adj = [[] for _ in range(n+1)]
    for u,v in edges:
        adj[u].append(v)
        adj[v].append(u)
    # Convert to a rooted tree representation using root
    # We'll do a BFS or DFS to get parent-child structure
    from collections import deque
    parent = [0]*(n+1)
    children = [[] for _ in range(n+1)]
    parent[root] = -1
    q = deque([root])
    visited = [False]*(n+1)
    visited[root] = True
    while q:
        u = q.popleft()
        for w in adj[u]:
            if not visited[w]:
                visited[w] = True
                parent[w] = u
                children[u].append(w)
                q.append(w)
    return parent, children

def initialize_dp(n, r, node_info, children):

    INF = float('-inf')
    d0 = [[INF]*(r+1) for _ in range(n+1)]
    d1 = [[INF]*(r+1) for _ in range(n+1)]
    d2 = [[INF]*(r+1) for _ in range(n+1)]
    return d0, d1, d2

def compute_dp(u, r, node_info, children, d0, d1, d2):

    for c in children[u]:
        compute_dp(c, r, node_info, children, d0, d1, d2)

    if len(children[u]) == 0:
        typ, w = node_info[u]

        if typ == 'f':
            # d0_u[0] = 0
            d0[u][0] = 0
            # d1_u[1] = 0 (to place u in R)
            if 1 <= r:
                d1[u][1] = 0
            # d2_u[b] is not defined for facilities
        else:
            # Leaf customer:
            # d0_u[0] = 0
            d0[u][0] = 0
            # d2_u[0] = w(u)
            d2[u][0] = w
            # d1_u[b] is not defined for customers
        return


    typ, w = node_info[u]


    INF = float('-inf')


    child_options_for_d0 = []
    for cnode in children[u]:
        arr = []
        for B in range(r+1):
            arr.append(max(d0[cnode][B], d1[cnode][B]))
        child_options_for_d0.append(arr)

    # For d1_u (if facility):
    # we take max(d0_vi[b], d1_vi[b], d2_vi[b])
    child_options_for_d1 = []
    if typ == 'f':
        for cnode in children[u]:
            arr = []
            for B in range(r+1):
                arr.append(max(d0[cnode][B], d1[cnode][B], d2[cnode][B]))
            child_options_for_d1.append(arr)

    # For d2_u (if customer):
    # we take max(d1_vi[b], d2_vi[b])
    child_options_for_d2 = []
    if typ == 'c':
        for cnode in children[u]:
            arr = []
            for B in range(r+1):
                arr.append(max(d1[cnode][B], d2[cnode][B]))
            child_options_for_d2.append(arr)


    def mckp_merge(arrays, budget):

        dp = [0 if i == 0 else INF for i in range(budget+1)]
        for arr in arrays:
            new_dp = [INF]*(budget+1)
            for B in range(budget+1):
                if dp[B] == INF:
                    continue
                for x in range(budget - B + 1):
                    val = dp[B] + arr[x]
                    if val > new_dp[B+x]:
                        new_dp[B+x] = val
            dp = new_dp
        return dp


    d0vals = mckp_merge(child_options_for_d0, r)
    for B in range(r+1):
        d0[u][B] = d0vals[B]


    if typ == 'f':

        for B in range(r+1):
            d1[u][B] = INF
        if r > 0:
            d1vals = mckp_merge(child_options_for_d1, r-1)
            for B in range(r):
                if d1vals[B] != INF:
                    d1[u][B+1] = d1vals[B]


    if typ == 'c':

        d2vals = mckp_merge(child_options_for_d2, r)
        for B in range(r+1):
            if d2vals[B] != INF:
                d2[u][B] = w + d2vals[B]

def convert_text_file_to_array(filename):
    with open(filename, "r") as file:
        content = file.read()


    tree_strings = [block for block in content.strip().split("\n\n") if block.strip()]
    return tree_strings


def main():

    tree_str = convert_text_file_to_array("trees_500Total_vN_0.5F_p=0.5_hw.txt")

    startTime1 = timeit.default_timer()

    for i in range(len(tree_str)):
        n, r, node_info, edges = read_input(tree_str[i])
        parent, children = build_tree(n, edges, root=1)
        d0, d1, d2 = initialize_dp(n, r, node_info, children)

        compute_dp(1, r, node_info, children, d0, d1, d2)

        ans = float('-inf')
        for B in range(r + 1):
            ans = max(ans, d0[1][B], d1[1][B])
        print("Maximum removed weight (Ali ) with budget <= {} is {}".format(r, ans))
    endTime1 = timeit.default_timer()

    print(endTime1 - startTime1)

if __name__ == "__main__":
    main()
