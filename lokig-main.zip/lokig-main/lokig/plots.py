import matplotlib.pyplot as plt
import numpy as np
from networkx.algorithms.bipartite.basic import color

# Categories for the x-axis
x = [50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000]

P = [0.1 , 0.2 , 0.3 , 0.4 , 0.5 , 0.6 , 0.7 , 0.8 , 0.9]
H = [35.7, 41.14, 44.02, 46.9, 50.12, 53.04, 56.26, 59.42, 64.68, 77.14]

B= [50 , 100 , 150 , 200 , 250 , 300, 350 , 400 , 450]
B_2 = [50 , 100 , 150 , 200 , 250 , 300]

Portion_0 = [0 , 0.1 , 0.2 , 0.3 , 0.4 , 0.5 , 0.6 , 0.7 , 0.8 , 0.9 , 1]
Portion_1 = [1 , 0.9 , 0.8 , 0.7 , 0.6 , 0.5 , 0.4 , 0.3, 0.2, 0.1 , 0]
# Runtime data (in seconds)
# Use np.nan for missing values (---)
#brute_force = [ 0.0691, 100.9417, np.nan, np.nan , np.nan , np.nan , np.nan]
alis_algo_5   = [ 0.9489, 2.4651 , 9.4810 , 23.4994 ,36.8891,67.8630 ,76.2994 , 104.3781 , 161.6557, 222.7334, 280.0440]
groubi_opt_5  = [0.6926,3.7482,  22.2359 , 67.3171 ,211.2253 , 341.9400,446.6770, 846.4604 , 1569.6261 , 1815.9444  , 2764.3969]
FR_N_5 = [0.8567 , 5.0031 , 34.3130, 65.8263 , 277.4566 , 555.0812, 356.0894 , 919.5318 , 981.3785 , 2861.1559 , 1232.8035]


DP_p_500 = [101.0531, 93.7655 , 82.9844 , 58.8752, 67.8630 , 62.5908 , 43.6429 , 38.6226 , 35.7719]
groubi_p_500 = [116.5592, 222.4210 , 295.7054 , 347.3969,341.9400, 321.9764, 281.0976 , 202.6295 , 107.7322 ]
FR_p_500 = [None, None, 5676, 1969.8553, 555.0812 , 73.3900, 34.6302, 22.8663,12.2762]

DP_p_200 = [13.0448, 13.5133 , 11.5229 , 9.6738, 9.7579 , 8.0061 , 6.4621 , 6.3507 , 4.7145]
groubi_p_200 = [7.7306, 16.1436 , 18.6261 , 18.6365,18.8187, 24.9139, 21.4205 , 10.1070 , 7.1349]
FR_p_200 = [6796.8067, 3872.5641, 510.3108, 176.9694, 34.3130 , 6.5590, 5.0094, 2.1942,0.9343]

DP_h = [63.1625, 64.3805 , 50.5548 , 56.3680 , 59.0558, 55.6959, 58.1608 , 58.2588 , 66.6658 , 64.5711]
groubi_h = [292.3589, 319.7962 , 327.3139 ,334.4779 ,  336.8677,341.0355, 341.8394 , 359.4790 , 363.1268 , 402.4997 ]
FR_h = [706.5164, 2388.0446,258.1144 ,248.1048,  186.4451,1022.6194, 315.5983, 283.2722, 303.5987 , 410.3802 ]

Groubi_b = [353.7979,346.0236,352.6568, 224.3392 , 290.5110 , 284.8008 , 330.6107 , 327.2877 , 273.5221]
DP_b = [12.3359,24.1518 , 36.3770, 48.9773, 61.1276 , 74.6187, 87.4193, 99.7542, 113.1782]
FR_b = [60.0871 , 178.0777 , 120.4575 ,  142.3411, 203.4516 , 436.8135 , 461.6594 , 480.3254 , 1341.7912]


EN_D_200 = [12.0492 , 229.7048 , 388 , 508 , 619, 625 , 611 , 505, 374 , 202 , 10.9563 ]
EN_G_200 = [24.8258 , 31.5787 , 39.7763 , 48.9984 , 41.6114 , 37.6651 , 34.3251 , 33.7083 , 25.5818 , 25.1749 , 31.0031 ]

EN_D_500 = [26.9209 , 505.6322 , 941.7356 , 1293.9695 , 1533.2642, 1655.1388 , 1567.3880 , 1335.5949, 1001.9289 , 589.4966 , 28.9327]
EN_G_500 = [370.4965 , 591.8124 , 727.3773, 681.4783 , 737.4631 , 704.9016 , 562.8453 , 526.7561 , 752.9867, 581.0665, 360 ]

EN_D_1000 = [54.1191 , 1020.9884 , 1878.5479 , 2605.5216 , 3151.7103, 3281.7323 , 3124.8280 , 2673.0562, 2020.8788 , 1159.9615 , 56.8895]

EN_G_1000 = [3769.7361, 6018.8, 7399.6, 6934.8, 7495.4,
             7166.9, 5722.9, 5359.1, 7656.3, 5909.4, 3661.2]

Gurobi_N_5 = [0.0129 , 0.0767 , 0.4452 , 1.3971 , 2.5331 , 7.0287 , 12.5877 , 19.4395 , 27.0106 , 39.4730 , 45.7735]
Gurobi_N_5_e = [0.0027 , 0.0072 , 0.0352 , 0.0535 , 0.1144 , 0.3175 , 0.5877 , 0.9858 , 1.3999, 1.6073 , 2.1416]
DP_N_5 =[0.0138 , 0.0486 , 0.1784 , 0.4566 , 0.8343 , 1.2003 , 1.9110 , 2.3646 , 3.3012 , 4.4045 , 5.8458]
DP_N_5_e = [0.0135, 0.0334 , 0.1215 , 0.2453 , 0.4645 , 0.7734 , 1.0699 , 1.4228 , 2.0723 , 2.6390 , 3.0557]
FR_N_5 = [0.0162 , 0.0711 , 0.8334 , 3.5114 , 4.4564 , 5.6037 , 10.2403 , 11.0346 , 23.3742 , 40.9130 , 29.4567]
FR_N_5_e = [0.0333 , 0.1321 , 3.4404 , 8.0829 , 8.7741 , 10.4869 , 23.8917 , 19.1491 , 58.9119 , 108.1558 , 38.2891]

Gurobi_P_200 = []
Gurobi_P_200_e = []
DP_P_200 =[0.2840 , 0.2424, 0.2452 , 0.2428 , 0.1784 , 0.1855 , 0.1965]
DP_P_200_e = [0.1660 , 0.1490 , 0.1390 , 0.1275 , 0.1215 , 0.0966 , 0.1337]
FR_P_200 = [0.0162 , 0.0711 , 0.8334 , 3.5114 , 4.4564 , 5.6037 , 10.2403,11.0346 , 23.3742 , 40.9130 , 29.4567]
FR_P_200_e = [0.0333 , 0.1321 , 3.4404 , 8.0829 , 8.7741 , 10.4869 , 23.8917 , 19.1491 , 58.9119 , 108.1558 , 38.2891]

Gurobi_B_500 = []
Gurobi_B_500_e = []
DP_B_500 =[]
DP_B_500_e = []
FR_B_500 = [0.0162 , 0.0711 , 0.8334 , 3.5114 , 4.4564 , 5.6037 , 10.2403,11.0346 , 23.3742 , 40.9130 , 29.4567]
FR_B_500_e = [0.0333 , 0.1321 , 3.4404 , 8.0829 , 8.7741 , 10.4869 , 23.8917 , 19.1491 , 58.9119 , 108.1558 , 38.2891]


import matplotlib.pyplot as plt
from matplotlib.ticker import AutoMinorLocator


fig, ax = plt.subplots(figsize=(10, 8))

ax.plot(Portion_1, EN_D_200,    marker='o', label="DP Algorithm")
ax.plot(Portion_1, EN_G_200, marker='o', label='Gurobi Optimization')


# Set major ticks at your budgets
ax.set_xticks(Portion_1)
minor_xticks = []
ax.set_xticks(minor_xticks, minor=True)
ax.yaxis.set_minor_locator(AutoMinorLocator(1))

# Turn on both major and minor grids
ax.grid(which='major', linestyle='-', linewidth=0.5)
ax.grid(which='minor', linestyle=':', linewidth=0.5)

# Labels, legend, etc.
ax.set_xlabel('Portion of Edge Removal Budget')
ax.set_ylabel('Time (seconds)')
ax.legend()

# Save and show
plt.savefig('output_EN_first_200.pdf')

fig, ax = plt.subplots(figsize=(10, 8))

ax.plot(Portion_0, EN_D_1000,    marker='o', label="DP Algorithm")
ax.plot(Portion_0, EN_G_1000, marker='o', label='Gurobi Optimization')


# Set major ticks at your budgets
ax.set_xticks(Portion_0)
minor_xticks = []
ax.set_xticks(minor_xticks, minor=True)
ax.yaxis.set_minor_locator(AutoMinorLocator(1))

# Turn on both major and minor grids
ax.grid(which='major', linestyle='-', linewidth=0.5)
ax.grid(which='minor', linestyle=':', linewidth=0.5)

# Labels, legend, etc.
ax.set_xlabel('Portion of Edge Removal Budget')
ax.set_ylabel('Time (seconds)')
ax.legend()

# Save and show
plt.savefig('output_EN_first_1000.pdf')

import matplotlib.pyplot as plt
from matplotlib.ticker import AutoMinorLocator


fig, ax = plt.subplots(figsize=(10, 8))

ax.plot(x, alis_algo_5,    marker='o', label="DP Algorithm")
ax.plot(x, groubi_opt_5, marker='o', label='Gurobi Optimization')
ax.plot(x, FR_N_5, marker='o', label='Frohlich Ruzika')

# Set major ticks at your budgets
ax.set_xticks(x)
minor_xticks = [150, 250 , 300, 350 ,400, 450]
ax.set_xticks(minor_xticks, minor=True)
ax.yaxis.set_minor_locator(AutoMinorLocator(1))

# Turn on both major and minor grids
ax.grid(which='major', linestyle='-', linewidth=0.5)
ax.grid(which='minor', linestyle=':', linewidth=0.5)

# Labels, legend, etc.
ax.set_xlabel('Tree Size')
ax.set_ylabel('Time (seconds)')
ax.legend()

# Save and show
plt.savefig('Final_output__n.pdf')


  # <-- your custom positions








plt.figure(figsize=(10, 5))

plt.plot(B, DP_b, marker='o', label="DP Algorithm")
plt.plot(B, Groubi_b, marker='o', label='Groubi Optimization')
plt.plot(B, FR_b, marker='o', label='Frohlich Ruzika')


# Format the plot
plt.xticks(B)
plt.xlabel('Number of Budget')
plt.ylabel('Time (seconds)')
#plt.title('Algorithm Runtimes for Varying Number of Nodes')
plt.legend()
plt.grid(True)

# Display the plot
plt.savefig('output_FR_b.pdf')


plt.figure(figsize=(10, 6))

plt.plot(P, DP_p_500, marker='o', label="DP Algorithm")
plt.plot(P, groubi_p_500, marker='o', label='Groubi Optimization')
plt.plot(P, FR_p_500, marker='o', label='Frohlich Ruzika')

# Format the plot
plt.xticks(P)
plt.xlabel('Facility Probability')
plt.ylabel('Time (seconds)')

#plt.title('Algorithm Runtimes for Varying Facility Probability')
plt.legend()
plt.grid(True)

# Display the plot
plt.savefig('output_FR_p.pdf')

plt.figure(figsize=(10, 6))

plt.plot(H, DP_h, marker='o', label="DP Algorithm")
plt.plot(H, groubi_h, marker='o', label='Groubi Optimization')
plt.plot(H, FR_h, marker='o', label='Fruhlich Ruzika')

# Format the plot
plt.xticks(H)
plt.xlabel('Tree Height')
plt.ylabel('Time (seconds)')
#plt.title('Algorithm Runtimes for Varying Tree Height')
plt.legend()
plt.grid(True)

# Display the plot
plt.savefig('output_H.pdf')


fig, ax = plt.subplots(figsize=(10, 8))

# Plot with error bars
ax.errorbar(x, DP_N_5, yerr=DP_N_5_e, fmt='-o', label="DP Algorithm", capsize=4)
ax.errorbar(x, Gurobi_N_5, yerr=Gurobi_N_5_e, fmt='-o', label='Gurobi Optimization', capsize=4)
ax.errorbar(x, FR_N_5, yerr=FR_N_5_e, fmt='-o', label='Fröhlich–Ruzika', capsize=4)

# Major and minor ticks
ax.set_xticks(x)
minor_xticks = [150, 250, 300, 350, 400, 450]
ax.set_xticks(minor_xticks, minor=True)
ax.yaxis.set_minor_locator(AutoMinorLocator(1))

# Grids
ax.grid(which='major', linestyle='-', linewidth=0.5)
ax.grid(which='minor', linestyle=':', linewidth=0.5)

# Labels, legend
ax.set_xlabel('Tree Size')
ax.set_ylabel('Time (seconds)')
ax.legend()
ax.set_ylim(bottom=0)
# Save and show
plt.savefig('Final_output__n.pdf')