from collections import deque, defaultdict
from math import inf
import timeit
import numpy as np

# >>> Set this to the "n" you want (percentage of largest clusters)
TOP_PERCENT = 5.0  # e.g., 10.0 means top 10% largest clusters by node count

def parse_input(data):
    """Parse input tree and budget."""
    lines = [l for l in data.strip().splitlines() if l.strip()]
    n, B = map(int, lines[0].split())
    node_info, idx = {}, 1
    for _ in range(n):
        parts = lines[idx].split()
        idx += 1
        u = int(parts[0])
        if parts[1] == 'f':
            node_info[u] = ('f', 0)
        else:
            # format for customers assumed: "<u> c <cost>"
            node_info[u] = ('c', int(parts[2]))
    m = int(lines[idx]); idx += 1
    edges = []
    for _ in range(m):
        u, v = map(int, lines[idx].split())
        idx += 1
        edges.append((u, v))
    return n, B, node_info, edges

def build_adj(n, edges):
    adj = {i: [] for i in range(1, n + 1)}
    for u, v in edges:
        adj[u].append(v)
        adj[v].append(u)
    return adj

def make_clusters(n, edges, node_info, adj=None):
    """
    Partition the tree into clusters: connected components of customers,
    plus any facilities adjacent to them.
    Returns list of (nodeset, cluster_edges).
    """
    if adj is None:
        adj = build_adj(n, edges)

    # Build adjacency among customers and map customers to adjacent facilities
    cust_adj = defaultdict(list)
    cust_to_facs = defaultdict(set)
    for u, v in edges:
        tu, tv = node_info[u][0], node_info[v][0]
        if tu == 'c' and tv == 'c':
            cust_adj[u].append(v)
            cust_adj[v].append(u)
        elif tu == 'c' and tv == 'f':
            cust_to_facs[u].add(v)
        elif tu == 'f' and tv == 'c':
            cust_to_facs[v].add(u)

    visited = set()
    clusters = []
    for u, (t, _) in node_info.items():
        if t != 'c' or u in visited:
            continue
        # DFS to collect one customer-component
        stack = [u]
        visited.add(u)
        custs = {u}
        while stack:
            v = stack.pop()
            for w in cust_adj[v]:
                if w not in visited:
                    visited.add(w)
                    custs.add(w)
                    stack.append(w)
        # Gather facilities adjacent to any customer in this component
        facs = set()
        for c in custs:
            facs |= cust_to_facs[c]
        nodeset = custs | facs
        # Extract edges inside the cluster
        cl_edges = []
        for v in nodeset:
            for w in adj[v]:
                if w in nodeset and v < w:
                    cl_edges.append((v, w))
        clusters.append((nodeset, cl_edges))
    return clusters

def convert_text_file_to_array(filename):
    with open(filename, "r") as f:
        return [block for block in f.read().strip().split("\n\n") if block.strip()]

# ---------- Metrics helpers ----------

def _bfs_farthest(start, adj):
    """Return (farthest_node, distance_dict) from start using BFS on an unweighted graph."""
    dist = {start: 0}
    dq = deque([start])
    while dq:
        u = dq.popleft()
        for v in adj[u]:
            if v not in dist:
                dist[v] = dist[u] + 1
                dq.append(v)
    far = max(dist, key=lambda x: dist[x])
    return far, dist

def tree_diameter(adj):
    """Diameter (in edges) of a tree via double BFS."""
    any_node = next(iter(adj))
    u, _ = _bfs_farthest(any_node, adj)
    v, dist = _bfs_farthest(u, adj)
    return dist[v]

def induced_subgraph_adj(nodeset, full_adj):
    """Adjacency dict for the induced subgraph on nodeset."""
    return {u: [v for v in full_adj[u] if v in nodeset] for u in nodeset}

def subgraph_diameter(nodeset, full_adj):
    """
    Diameter (in edges) of the induced subgraph on nodeset.
    Since the whole graph is a tree, the induced subgraph is a forest; but
    each cluster constructed here is connected, so double-BFS works.
    """
    if not nodeset:
        return 0
    sub_adj = induced_subgraph_adj(nodeset, full_adj)
    any_node = next(iter(sub_adj))
    u, _ = _bfs_farthest(any_node, sub_adj)
    v, dist = _bfs_farthest(u, sub_adj)
    return dist[v]

def largest_cluster_size_and_count(n, edges, node_info, adj=None):
    clusters = make_clusters(n, edges, node_info, adj)
    if not clusters:
        return 0, 0
    max_size = max(len(nodeset) for nodeset, _ in clusters)
    return max_size, len(clusters)

def avg_facility_percentage_across_clusters(n, edges, node_info, adj=None):
    """
    For each cluster, compute (#facilities) / (cluster_size),
    then return the average of these percentages across all clusters.
    """
    clusters = make_clusters(n, edges, node_info, adj)
    if not clusters:
        return 0.0
    percs = []
    for nodeset, _ in clusters:
        facs = sum(1 for u in nodeset if node_info[u][0] == 'f')
        size = len(nodeset)
        percs.append(facs / size if size > 0 else 0.0)
    return float(np.mean(percs))

def max_customers_in_any_cluster(n, edges, node_info, adj=None):
    """Return the maximum number of customers across all clusters."""
    clusters = make_clusters(n, edges, node_info, adj)
    if not clusters:
        return 0
    max_c = 0
    for nodeset, _ in clusters:
        ccount = sum(1 for u in nodeset if node_info[u][0] == 'c')
        if ccount > max_c:
            max_c = ccount
    return max_c

def avg_cluster_size_across_clusters(n, edges, node_info, adj=None):
    """Average total cluster size (customers + facilities) across clusters."""
    clusters = make_clusters(n, edges, node_info, adj)
    if not clusters:
        return 0.0
    sizes = [len(nodeset) for nodeset, _ in clusters]
    return float(np.mean(sizes))

# ---------- Variance helpers (across clusters within a tree) ----------

def cluster_size_variances(n, edges, node_info, adj=None):
    """
    Returns a triple of population variances across clusters in this tree:
      - var_cluster_size: variance of total nodes per cluster
      - var_customers_per_cluster: variance of #customers per cluster
      - var_facilities_per_cluster: variance of #facilities per cluster
    """
    clusters = make_clusters(n, edges, node_info, adj)
    if not clusters:
        return 0.0, 0.0, 0.0

    sizes = []
    cust_counts = []
    fac_counts = []
    for nodeset, _ in clusters:
        size = len(nodeset)
        ccount = sum(1 for u in nodeset if node_info[u][0] == 'c')
        fcount = size - ccount
        sizes.append(size)
        cust_counts.append(ccount)
        fac_counts.append(fcount)

    var_size = float(np.var(sizes, ddof=0))            # population variance
    var_cust = float(np.var(cust_counts, ddof=0))      # population variance
    var_fac  = float(np.var(fac_counts, ddof=0))       # population variance
    return var_size, var_cust, var_fac

# ---------- Top-n% largest clusters averages (extended with size & diameter) ----------

def top_percent_clusters_avg_counts(n, edges, node_info, adj=None, top_percent=10.0):
    """
    Among the top `top_percent` percent largest clusters (by total nodes),
    return (avg_customers, avg_facilities, avg_size, avg_diameter, k_selected).
    Always selects at least 1 cluster if any exist.
    """
    clusters = make_clusters(n, edges, node_info, adj)
    if not clusters or top_percent <= 0:
        return 0.0, 0.0, 0.0, 0.0, 0

    # Compute per-cluster statistics
    stats = []
    for nodeset, _ in clusters:
        size = len(nodeset)
        ccount = sum(1 for u in nodeset if node_info[u][0] == 'c')
        fcount = size - ccount  # remaining nodes are facilities
        diam = subgraph_diameter(nodeset, adj if adj is not None else build_adj(len(node_info), []))
        stats.append((size, ccount, fcount, diam))

    # Sort by size (desc)
    stats.sort(key=lambda t: t[0], reverse=True)

    # How many to select?
    k = int(np.ceil(len(stats) * (top_percent / 100.0)))
    k = max(1, min(k, len(stats)))

    top = stats[:k]
    avg_customers = float(np.mean([cc for _, cc, _, _ in top]))
    avg_facilities = float(np.mean([fc for _, _, fc, _ in top]))
    avg_size = float(np.mean([sz for sz, _, _, _ in top]))
    avg_diameter = float(np.mean([dm for _, _, _, dm in top]))
    return avg_customers, avg_facilities, avg_size, avg_diameter, k

# ---------- Main ----------

def main():
    input_filename = "old_data/trees_Edge_500Total_60N_0.5F_E_Integer_leaves.txt"
    tree_blocks = convert_text_file_to_array(input_filename)

    results_lines = []

    for idx, data in enumerate(tree_blocks, start=0):
        n, B, node_info, edges = parse_input(data)
        adj = build_adj(n, edges)

        # Metrics
        diam = tree_diameter(adj)
        max_cluster_size, num_clusters = largest_cluster_size_and_count(n, edges, node_info, adj)

        # Average facility percentage across clusters
        avg_facility_pct = avg_facility_percentage_across_clusters(n, edges, node_info, adj)

        # Max customers in any cluster
        max_cust_in_cluster = max_customers_in_any_cluster(n, edges, node_info, adj)

        # Average cluster size (customers + facilities)
        avg_cluster_size = avg_cluster_size_across_clusters(n, edges, node_info, adj)

        # Variances across clusters within this tree
        var_cluster_size, var_cust_per_cluster, var_fac_per_cluster = cluster_size_variances(
            n, edges, node_info, adj
        )

        # Top-n% largest clusters averages (now includes size & diameter)
        top_avg_cust, top_avg_fac, top_avg_size, top_avg_diam, top_k = top_percent_clusters_avg_counts(
            n, edges, node_info, adj, top_percent=TOP_PERCENT
        )

        results_lines.append(
            f"Answer {idx}: diameter={diam}, "
            f"max_cluster_size={max_cluster_size}, "
            f"num_clusters={num_clusters}, "
            f"avg_facility_percentage={avg_facility_pct:.6f}, "
            f"max_customers_in_cluster={max_cust_in_cluster}, "
            f"avg_cluster_size={avg_cluster_size:.6f}, "
            f"var_cluster_size={var_cluster_size:.6f}, "
            f"var_customers_per_cluster={var_cust_per_cluster:.6f}, "
            f"var_facilities_per_cluster={var_fac_per_cluster:.6f}, "
            f"top{int(TOP_PERCENT)}p_avg_customers={top_avg_cust:.3f}, "
            f"top{int(TOP_PERCENT)}p_avg_facilities={top_avg_fac:.3f}, "
            f"top{int(TOP_PERCENT)}p_avg_nodes={top_avg_size:.3f}, "
            f"top{int(TOP_PERCENT)}p_avg_diameter={top_avg_diam:.3f} "
            f"(k={top_k})"
        )

    # Write output file
    out_fn = "Final_Result_Parameters_60_500_extend.txt"
    with open(out_fn, "w") as f:
        for line in results_lines:
            f.write(line + "\n")

    print(f"Wrote {len(results_lines)} lines to {out_fn}")

if __name__ == "__main__":
    main()
