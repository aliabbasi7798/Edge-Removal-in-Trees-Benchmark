from collections import defaultdict, deque
import timeit
def read_input(data):
    lines = data.strip().split('\n')
    n, r = map(int, lines[0].split())
    #print(r)
    node_info = {}
    idx = 1
    for _ in range(n):
        parts = lines[idx].split()
        idx += 1
        u = int(parts[0])
        typ = parts[1]
        if typ == 'f':
            node_info[u] = ('f', 0)
        else:
            w = int(parts[2])
            node_info[u] = ('c', w)

    m = int(lines[idx])
    idx += 1
    edges = []
    for _ in range(m):
        u, v = map(int, lines[idx].split())
        idx += 1
        edges.append((u, v))
    return n, r, node_info, edges

def build_tree(n, edges, root=1):
    adj = [[] for _ in range(n + 1)]
    for u, v in edges:
        adj[u].append(v)
        adj[v].append(u)

    parent = [0] * (n + 1)
    children = [[] for _ in range(n + 1)]
    visited = [False] * (n + 1)
    visited[root] = True
    parent[root] = -1

    queue = deque([root])
    while queue:
        u = queue.popleft()
        for w in adj[u]:
            if not visited[w]:
                visited[w] = True
                parent[w] = u
                children[u].append(w)
                queue.append(w)
    return parent, children

def is_joint(u, node_info, children):
    typ, _ = node_info[u]
    return (typ == 'c' and len(children[u]) > 0)

def identify_leaf_strings(n, node_info, parent, children):
    leaf_strings = []
    #print(node_info)
    # Iterate from 1 to n (inclusive) because nodes are 1-indexed.
    for u in range(1, n + 1):
        typ, _ = node_info[u]
        # a leaf in T* is a customer with no children.
        if len(children[u]) == 0 and typ == 'c':
            # trace upward until hitting a facility or a joint
            string_nodes = [u]
            cur = u
            while True:
                p = parent[cur]
                if p == -1 or p==0:
                    # reached the root (a facility)
                    break
                #print(p)
                #print(node_info[p+1])
                ptyp, _ = node_info[p]
                # stop if p is facility or p is a joint (has more than one child)
                if ptyp == 'f' or (ptyp == 'c' and len(children[p]) > 1):
                    string_nodes.append(p)
                    string_nodes.reverse()
                    pnode = string_nodes[0]
                    leaf_string = string_nodes[1:]
                    leaf_strings.append((pnode, leaf_string))
                    break
                else:
                    # continue upward
                    string_nodes.append(p)
                    cur = p
    return leaf_strings

def slide_leaf_strings(node_info, parent, children):
    while True:
        # n is the number of nodes; note that node_info keys are 1-indexed.
        n = len(node_info)
        leaf_strings = identify_leaf_strings(n, node_info, parent, children)
        #print("Leaf strings:", leaf_strings)
        if not leaf_strings:
            #print("No more leaf strings to slide.")
            break

        for pnode, string_nodes in leaf_strings:
            # Sum weights along the leaf string
            total_w = sum(node_info[x][1] for x in string_nodes)
            ptyp, pw = node_info[pnode]
            node_info[pnode] = (ptyp, pw + total_w)

            # Remove the nodes in the string from the tree
            to_remove = set(string_nodes)
            children[pnode] = [c for c in children[pnode] if c not in to_remove]
            for x in string_nodes:
                # clear children and reset weight
                children[x].clear()
                node_info[x] = ('c', 0)
                parent[x] = 0

def identify_branch_strings(n, node_info, parent, children):
    branch_strings = []

    def is_fac_or_joint(u):
        typ, _ = node_info[u]
        if typ == 'f':
            return True
        if typ == 'c' and len(children[u]) > 0:  # joint
            return True
        return False

    visited = [False] * (n + 1)

    def dfs(u):
        visited[u] = True
        for c in children[u]:
            if not visited[c]:
                # if u is a facility/joint and c is a non-joint customer, it's the start of a branch
                if is_fac_or_joint(u):
                    ctyp, _ = node_info[c]
                    if ctyp == 'c' and not is_joint(c, node_info, children):
                        path = [c]
                        cur = c
                        while True:
                            if is_fac_or_joint(cur):
                                break
                            if len(children[cur]) == 0:
                                break
                            nxt = children[cur][0]
                            if is_fac_or_joint(nxt):
                                path.append(nxt)
                                break
                            else:
                                path.append(nxt)
                                cur = nxt
                        if len(path) > 1:
                            branch_strings.append((u, path[-1], path[:-1]))
                dfs(c)

    # Iterate over nodes 1 to n to find the root (where parent is -1)
    for v in range(1, n + 1):
        if parent[v] == -1:
            dfs(v)
    return branch_strings

def compress_branch_strings(node_info, parent, children):
    edge_weights = defaultdict(int)
    n = len(node_info)
    branch_strings = identify_branch_strings(n, node_info, parent, children)
    for start, end, branch_nodes in branch_strings:
        # Sum weights along the branch
        total_w = sum(node_info[x][1] for x in branch_nodes)
        key = (start, end) if start < end else (end, start)
        edge_weights[key] += total_w

        # Remove branch_nodes from tree by replacing them with end
        ch = children[start]
        first = branch_nodes[0]
        new_ch = []
        replaced = False
        for c in ch:
            if c == first and not replaced:
                new_ch.append(end)
                replaced = True
            elif c not in branch_nodes:
                new_ch.append(c)
        children[start] = new_ch
        parent[end] = start

        for x in branch_nodes:
            parent[x] = 0
            children[x].clear()
            node_info[x] = ('c', 0)

    return edge_weights

def is_facility(u, node_info):
    """Return True if node u is a facility."""
    return node_info[u][0] == 'f'

def get_edge_weight(u, v, edge_weights):
    """Retrieve the compressed edge weight w(u,v)."""
    key = (u, v) if u < v else (v, u)
    return edge_weights.get(key, 0)

def compute_dp(n, r, root, node_info, parent, children, edge_weights):
    """
    Build dp[u][alpha][b] for alpha in {0,1,2} and b in [0..r] using a post-order DFS.
    """
    dp = [[[float('-inf')] * (r + 1) for _ in range(3)] for _ in range(n + 1)]
    visited = [False] * (n + 1)

    def dfs(u):
        visited[u] = True
        for c in children[u]:
            if not visited[c]:
                dfs(c)
        do_dp_for_node(u, dp, node_info, parent, children, edge_weights, r)

    dfs(root)
    return dp

def initialize_leaf(u, dp, node_info, r):
    typ, w_u = node_info[u]
    if typ == 'f':
        dp[u][0][0] = 0
        if r >= 1:
            dp[u][1][1] = w_u
    else:
        dp[u][0][0] = 0
    # The other dp values remain -∞.

def branch_update(u, v, dp, node_info, edge_weights, r):
    _, w_u = node_info[u]
    w_uv = get_edge_weight(u, v, edge_weights)
    for b in range(r + 1):
        # alpha=0: no extra budget spent at u
        dp[u][0][b] = max(dp[v][0][b], dp[v][1][b])
        # alpha=1: spending at least one unit at u
        if b >= 1:
            cand0 = dp[v][0][b - 1]
            cand1 = dp[v][1][b - 1] + w_uv
            cand2 = dp[v][2][b - 1] + w_uv
            dp[u][1][b] = w_u + max(cand0, cand1, cand2)
        else:
            dp[u][1][b] = float('-inf')
        # alpha=2 is invalid here.
        dp[u][2][b] = float('-inf')

def do_multiple_choice_knapsack(dp_start, list_of_arrays, r, base_val=0):
    """
    Combine contributions from multiple children via a Multiple Choice Knapsack.
    """
    dp_cur = dp_start[:]
    for child_array in list_of_arrays:
        new_dp = [float('-inf')] * (r + 1)
        for b_used in range(r + 1):
            val_so_far = dp_cur[b_used]
            if val_so_far == float('-inf'):
                continue
            # Distribute additional budget x to the current child.
            for x in range(r - b_used + 1):
                val_child = child_array[x]
                if val_child == float('-inf'):
                    continue
                cand = val_so_far + val_child
                if cand > new_dp[b_used + x]:
                    new_dp[b_used + x] = cand
        dp_cur = new_dp
    # Add base_val to every valid entry.
    for b_used in range(r + 1):
        if dp_cur[b_used] != float('-inf'):
            dp_cur[b_used] += base_val
    return dp_cur

def merge_update(u, dp, node_info, children, edge_weights, r):
    typ, w_u = node_info[u]
    c = children[u]
    # Build contributions from each child.
    child_contrib_0 = []
    child_contrib_1 = []
    child_contrib_2 = []
    for v in c:
        arr0 = [float('-inf')] * (r + 1)
        arr1 = [float('-inf')] * (r + 1)
        arr2 = [float('-inf')] * (r + 1)
        w_uv = get_edge_weight(u, v, edge_weights)
        for b_ in range(r + 1):
            arr0[b_] = max(dp[v][0][b_], dp[v][1][b_])
        if typ == 'f':
            for b_ in range(r + 1):
                cand0 = dp[v][0][b_]
                cand1 = dp[v][1][b_] + w_uv
                cand2 = dp[v][2][b_] + w_uv
                arr1[b_] = max(cand0, cand1, cand2)
        if typ == 'c' and len(c) > 0:  # for a joint
            for b_ in range(r + 1):
                cand1 = dp[v][1][b_]
                cand2 = dp[v][2][b_]
                arr2[b_] = w_uv + max(cand1, cand2)
        child_contrib_0.append(arr0)
        child_contrib_1.append(arr1)
        child_contrib_2.append(arr2)

    # Merge child contributions via Multiple Choice Knapsack.
    init0 = [0] + [float('-inf')] * r
    merge_0 = do_multiple_choice_knapsack(init0, child_contrib_0, r, base_val=0)

    merge_1 = [float('-inf')] * (r + 1)
    if typ == 'f':
        init1 = [0] + [float('-inf')] * r
        tmp_1 = do_multiple_choice_knapsack(init1, child_contrib_1, r, base_val=0)
        for b_ in range(r + 1):
            if b_ >= 1 and tmp_1[b_] != float('-inf'):
                merge_1[b_] = w_u + tmp_1[b_]

    merge_2 = [float('-inf')] * (r + 1)
    if typ == 'c' and len(c) > 0:  # a joint
        init2 = [0] + [float('-inf')] * r
        tmp_2 = do_multiple_choice_knapsack(init2, child_contrib_2, r, base_val=0)
        for b_ in range(r + 1):
            if tmp_2[b_] != float('-inf'):
                merge_2[b_] = w_u + tmp_2[b_]

    for b_ in range(r + 1):
        dp[u][0][b_] = merge_0[b_]
        dp[u][1][b_] = merge_1[b_]
        dp[u][2][b_] = merge_2[b_]

def do_dp_for_node(u, dp, node_info, parent, children, edge_weights, r):
    """
    For node u, decide whether to initialize (if leaf), perform a branch update,
    or a merge update.
    """
    if len(children[u]) == 0:
        initialize_leaf(u, dp, node_info, r)
        return

    c = children[u]
    if is_facility(u, node_info) and len(c) == 1:
        v = c[0]
        if not is_joint(v, node_info, children):
            branch_update(u, v, dp, node_info, edge_weights, r)
            return

    merge_update(u, dp, node_info, children, edge_weights, r)

def convert_text_file_to_array(filename):
    with open(filename, "r") as file:
        content = file.read()
    tree_strings = [block for block in content.strip().split("\n\n") if block.strip()]
    return tree_strings

if __name__ == "__main__":
    # Read trees from file; adjust filename as needed.
    tree_str = convert_text_file_to_array("trees_500Total_vN_0.5F_p=0.5_hw.txt")

    startTime1 = timeit.default_timer()

    for i in range(len(tree_str)):
        n, r, node_info, edges = read_input(tree_str[i])
        #print("Initial node info:", node_info)
        root = 1  # Assuming node 1 is a facility and chosen as the root.
        #print("Starting tree build...")
        parent, children = build_tree(n, edges, root)
        #print("Tree built. Starting slide lemma...")
        slide_leaf_strings(node_info, parent, children)
        #print("Slide lemma completed. Starting branch compression...")
        edge_weights = compress_branch_strings(node_info, parent, children)
        #print("Edge weights computed. Starting DP...")
        dp = compute_dp(n, r, root, node_info, parent, children, edge_weights)
        ans = max(dp[root][0][r], dp[root][1][r])
        print(f"Maximum interdicted weight for n={n}, r={r} is: {ans}")
    endTime1 = timeit.default_timer()

    print(endTime1 - startTime1)
