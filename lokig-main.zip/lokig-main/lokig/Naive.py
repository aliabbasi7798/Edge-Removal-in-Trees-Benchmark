from collections import deque
from itertools import combinations
import timeit


def solve_with_data(data_str):


    lines = data_str.strip().split('\n')

    n, r = map(int, lines[0].split())
    node_type = {}
    node_weight = {}

    idx = 1
    for _ in range(n):
        parts = lines[idx].split()
        idx += 1

        node_id = int(parts[0])
        node_kind = parts[1]

        if node_kind == 'f':
            node_type[node_id] = 'F'
            node_weight[node_id] = 0
        else:
            node_type[node_id] = 'C'
            weight = int(parts[2])
            node_weight[node_id] = weight


    e = int(lines[idx])
    idx += 1

    edges = []
    for _ in range(e):
        u, v = map(int, lines[idx].split())
        idx += 1
        edges.append((u, v))


    graph = {i: [] for i in range(1, n + 1)}
    for (u, v) in edges:
        graph[u].append(v)
        graph[v].append(u)


    facility_nodes = [node for node in range(1, n + 1) if node_type[node] == 'F']


    def compute_lost_weight(removed_facilities):

        removed_set = set(removed_facilities)


        connected_nodes = set()


        for f in facility_nodes:
            if f in removed_set:
                continue

            queue = deque([f])
            visited = {f}

            while queue:
                cur = queue.popleft()
                for nxt in graph[cur]:

                    if nxt not in visited:

                        if node_type[nxt] == 'F' and nxt in removed_set:
                            continue

                        visited.add(nxt)
                        queue.append(nxt)


            connected_nodes |= visited


        lost_sum = 0
        for node in range(1, n + 1):
            if node_type[node] == 'C' and node not in connected_nodes:
                lost_sum += node_weight[node]

        return lost_sum


    best_lost_weight = 0


    for remove_size in range(r + 1):
        for subset in combinations(facility_nodes, remove_size):
            lost_w = compute_lost_weight(subset)
            if lost_w > best_lost_weight:
                best_lost_weight = lost_w

    print("Maximum lost customer weight:", best_lost_weight)

def convert_text_file_to_array(filename):
    """
    Reads the file and splits the contents into separate data blocks (trees).
    """
    with open(filename, "r") as file:
        content = file.read()

    tree_strings = [block for block in content.strip().split("\n\n") if block.strip()]
    return tree_strings


if __name__ == "__main__":
    tree_str = convert_text_file_to_array("trees_50Total_vN_0.5F.txt")
    startTime3 = timeit.default_timer()
    for i in range(40):
        solve_with_data(tree_str[i])
    endTime3 = timeit.default_timer()
    print("Total run time:", endTime3 - startTime3)