import gurobipy as gp
from gurobipy import GRB
import networkx as nx
import timeit

# ---------- Parsing & graph ----------
import re

def parse_input(data):
    """
    Header format (required):  'n Be Bv ...'
    Next n lines:              '<id> f'  OR  '<id> c <weight>'
    Then (after anything, including blank lines): edges, one per line.
      - Accepts 'u v', 'u   v', 'u v w' (we take u,v), comments after '#'
      - Skips lines that do not contain at least two integers
    """
    raw_lines = data.splitlines()

    # --- header ---
    if not raw_lines:
        raise ValueError("Empty instance")
    header_ints = list(map(int, re.findall(r"-?\d+", raw_lines[0])))
    if len(header_ints) < 3:
        raise ValueError(f"Header must begin with: n Be Bv ...  Got: {raw_lines[0]!r}")
    n, Be, Bv = header_ints[0], header_ints[1], header_ints[2]

    # --- nodes ---
    node_lines = []
    i = 1
    while len(node_lines) < n and i < len(raw_lines):
        line = raw_lines[i].strip()
        i += 1
        if not line:
            continue
        node_lines.append(line)
    if len(node_lines) < n:
        raise ValueError(f"Expected {n} node lines, found {len(node_lines)}.")

    node_data = []
    for idx, line in enumerate(node_lines, start=1):
        # allow comments: "12 c 7 # comment"
        parts = re.split(r"\s+", line.split("#", 1)[0].strip())
        if len(parts) < 2:
            raise ValueError(f"Bad node line #{idx}: {line!r}")
        nid = int(parts[0])
        if parts[1].lower() == "f":
            node_data.append((nid, 'f'))
        elif parts[1].lower() == "c":
            if len(parts) < 3:
                raise ValueError(f"Customer node missing weight on line #{idx}: {line!r}")
            wt = int(parts[2])
            node_data.append((nid, 'c', wt))
        else:
            raise ValueError(f"Unknown node type on line #{idx}: {line!r}")

    # --- edges (everything after i) ---
    edge_data = []
    malformed_edges = []
    for j in range(i, len(raw_lines)):
        # strip comments
        line = raw_lines[j].split("#", 1)[0].strip()
        if not line:
            continue
        ints = re.findall(r"-?\d+", line)
        if len(ints) >= 2:
            u, v = int(ints[0]), int(ints[1])
            if u == v:
                malformed_edges.append((j+1, raw_lines[j], "self-loop"))
                continue
            edge_data.append((u, v))
        else:
            # record the exact bad line and keep going
            malformed_edges.append((j+1, raw_lines[j], "expected at least two integers"))

    # Optional: if you prefer a hard fail on malformed edges, uncomment:
    # if malformed_edges:
    #     details = "\n".join(f"  line {ln}: {txt!r} ({why})" for ln, txt, why in malformed_edges)
    #     raise ValueError("Malformed edge lines:\n" + details)

    # Sanity check: a tree with |V|=n should have exactly n-1 edges.
    # We don't *require* that (some files include non-tree extras), but warn if way off.
    if len(edge_data) < max(0, len(node_data) - 1):
        msg = [
            f"Too few edges parsed: got {len(edge_data)}, expected at least {len(node_data)-1} for a tree.",
        ]
        if malformed_edges:
            msg.append("Malformed edge lines (showing up to 5):")
            for ln, txt, why in malformed_edges[:5]:
                msg.append(f"  line {ln}: {txt!r}  -> {why}")
        raise ValueError("\n".join(msg))

    return n, Be, Bv, node_data, edge_data

def build_graph(node_data, edge_data):
    V = [node[0] for node in node_data]
    S = [node[0] for node in node_data if node[1] == 'f']          # facilities
    W = {node[0]: node[2] for node in node_data if node[1] == 'c'} # customer weights
    E_set = [frozenset(e) for e in edge_data]                       # edge keys

    T = nx.Graph()
    T.add_nodes_from(V)
    T.add_edges_from(edge_data)

    paths_nodes = {}  # v -> {s: [interior customer nodes]}
    paths_edges = {}  # v -> {s: [edges as frozensets]}
    customers = [v for v in V if v not in S]

    for v in customers:
        paths_nodes[v] = {}
        paths_edges[v] = {}
        for s in S:
            try:
                p = nx.shortest_path(T, v, s)  # unique in trees
            except nx.NetworkXNoPath:
                p = []

            interior = p[1:-1] if len(p) >= 2 else []
            interior_customers = [u for u in interior if u not in S]
            pedges = [frozenset((p[i], p[i+1])) for i in range(len(p)-1)]

            paths_nodes[v][s] = interior_customers
            paths_edges[v][s] = pedges

    return V, S, W, E_set, paths_nodes, paths_edges

# ---------- Model ----------
def optimize_model(V, S, W, E_set, paths_nodes, paths_edges, Bv, Be, gurobi_verbosity=0):
    customers = [v for v in V if v not in S]
    m = gp.Model("mixed_node_edge_interdiction")
    m.Params.OutputFlag = gurobi_verbosity

    x = m.addVars(customers, vtype=GRB.BINARY, name="x")           # 1 if v is connected
    y_node = m.addVars(customers, vtype=GRB.BINARY, name="y_node") # 1 if customer removed
    y_edge = m.addVars(E_set, vtype=GRB.BINARY, name="y_edge")     # 1 if edge removed

    m.setObjective(gp.quicksum(W[v] * (1 - x[v]) for v in customers), GRB.MAXIMIZE)

    for v in customers:
        for s in S:
            m.addConstr(
                x[v]
                + y_node[v]
                + gp.quicksum(y_node[u] for u in paths_nodes[v][s])
                + gp.quicksum(y_edge[e] for e in paths_edges[v][s])
                >= 1,
                name=f"path_constr_{v}_{s}"
            )

    m.addConstr(y_node.sum() <= Bv, name="node_budget")
    m.addConstr(y_edge.sum() <= Be, name="edge_budget")

    m.optimize()
    return m, x, y_node, y_edge

# ---------- Wrapper ----------
def solve_with_data(data):
    """
    Reads Bv, Be from the header. Returns:
    (optimal_value, disconnected_customers, removed_nodes, removed_edges)
    """
    n, Be, Bv, node_data, edge_data = parse_input(data)
    V, S, W, E_set, paths_nodes, paths_edges = build_graph(node_data, edge_data)
    m, x, y_node, y_edge = optimize_model(V, S, W, E_set, paths_nodes, paths_edges, Bv, Be)

    opt = None
    discon, rem_nodes, rem_edges = [], [], []
    if m.status == GRB.OPTIMAL:
        customers = [v for v in V if v not in S]
        discon = [v for v in customers if x[v].X < 0.5]
        rem_nodes = [v for v in customers if y_node[v].X > 0.5]
        rem_edges = [tuple(e) for e in E_set if y_edge[e].X > 0.5]
        opt = sum(W[v] for v in discon)
    return opt, discon, rem_nodes, rem_edges

# ---------- Batch ----------
def convert_text_file_to_array(filename):
    with open(filename, "r") as f:
        content = f.read()
    # assumes blank-line-separated instances
    return [blk for blk in content.strip().split("\n\n") if blk.strip()]

if __name__ == "__main__":
    tree_instances = convert_text_file_to_array("old_data/trees_Edge_Node_50Total_1000N_0.5F_E_Integer_BE_50.txt")
    #print(tree_instances)
    start_time = timeit.default_timer()
    answers = []
    for i, inst in enumerate(tree_instances):

        val, discon, rem_nodes, rem_edges = solve_with_data(inst)
        print(val)
        answers.append(val if val is not None else float("nan"))

    total_time = timeit.default_timer() - start_time
    with open("Result_EN_test_Groubi_1000_E_50.txt", "w") as f:
        for idx, ans in enumerate(answers):
            f.write(f"Answer {idx + 1}: {ans}\n")
        f.write(f"\nTotal run time: {total_time:.4f} seconds\n")
