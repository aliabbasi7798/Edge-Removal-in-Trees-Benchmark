import gurobipy as gp
from gurobipy import GRB
import timeit


def parse_data(data_str):
    """
    Parse the multi-line data string into:
      - n, r (ints)
      - facilities (list of node IDs)
      - customers (dict: node_id -> weight)
      - m (int)
      - edges (list of (u, v) pairs)
    """
    lines = data_str.strip().split('\n')

    # 1) First line: e.g., "25 8" => n=25, r=8
    n, r = map(int, lines[0].split())

    # 2) Next n lines describe each node
    facilities = []
    customers = {}

    # Each line looks like: "ID f" (facility) or "ID c WEIGHT" (customer)
    for i in range(1, n + 1):
        parts = lines[i].split()
        node_id = int(parts[0])
        node_type = parts[1]  # 'f' or 'c'

        if node_type == 'f':
            facilities.append(node_id)
        else:
            weight = int(parts[2])
            customers[node_id] = weight

    # 3) Next line has the number of edges m
    m = int(lines[n + 1])

    # 4) Next m lines: each "u v"
    edges = []
    start_edges = n + 2
    end_edges = n + 2 + m
    for i in range(start_edges, end_edges):
        u, v = map(int, lines[i].split())
        edges.append((u, v))

    return n, r, facilities, customers, m, edges


def build_adjacency(n, edges):
    """
    Build an adjacency dictionary: adjacency[node] = set of neighbors.
    """
    adjacency = {i: set() for i in range(1, n + 1)}
    for (u, v) in edges:
        adjacency[u].add(v)
        adjacency[v].add(u)
    return adjacency


def solve_r_facility_interdiction(I, J, w, N, r):
    """
    Solve the r-Facility Interdiction Covering Problem.

    I : list of facility nodes
    J : list of customer nodes
    w : dict of weights for each customer j in J
    N : dict, where N[j] is the list of facilities (reachable from j)
    r : number of facilities to interdict
    """
    # Create a new Gurobi model
    model = gp.Model("r_facility_interdiction")

    # Binary variable: s[i] = 1 if facility i is interdicted; 0 otherwise.
    s = model.addVars(I, vtype=GRB.BINARY, name="s")

    # Binary variable: t[j] = 1 if customer j is covered (i.e., at least one reachable facility is not interdicted)
    t = model.addVars(J, vtype=GRB.BINARY, name="t")

    # Constraint: Exactly r facilities are interdicted.
    model.addConstr(gp.quicksum(s[i] for i in I) == r, name="budget_interdiction")

    # Coverage constraints: For each customer j, if any reachable facility i is not interdicted (s[i] == 0),
    # then t[j] must be 1.
    for j in J:
        for i in N[j]:
            model.addConstr(t[j] >= 1 - s[i], name=f"cover_{j}_from_{i}")

    # Objective: maximize the total weight of uncovered customers.
    # For each customer j, the contribution is w[j]*(1-t[j]), which is w[j] if uncovered and 0 if covered.
    model.setObjective(gp.quicksum(w[j] * (1 - t[j]) for j in J), GRB.MAXIMIZE)

    # Solve the model.
    model.optimize()

    # Extract the solution.
    sSol = {i: s[i].X for i in I}
    tSol = {j: t[j].X for j in J}

    return model, sSol, tSol


def connected_component(start, adjacency):
    """
    Compute the connected component containing 'start' using BFS.
    Returns a set of nodes that are reachable from 'start'.
    """
    comp = set()
    queue = [start]
    while queue:
        node = queue.pop(0)
        if node not in comp:
            comp.add(node)
            queue.extend(adjacency[node] - comp)
    return comp


def solve_interdiction_from_data(data_str):
    """
    Parse the data, compute connected components for each customer to determine
    all reachable facilities, and then solve the interdiction problem.
    """
    # 1) Parse input data.
    n, r, facilities, customers, m, edges = parse_data(data_str)

    # 2) Build the graph's adjacency dictionary.
    adjacency = build_adjacency(n, edges)

    # 3) Build coverage sets: For each customer j, N[j] is the set of all facilities
    #    reachable from j (i.e., all facilities in j's connected component).
    I = facilities
    J = list(customers.keys())
    facility_set = set(I)
    N = {}
    for j in J:
        # Get the full connected component of customer j.
        comp = connected_component(j, adjacency)
        # Keep only the nodes that are facilities.
        N[j] = [i for i in comp if i in facility_set]

    # 4) Build weight dictionary.
    w = {j: customers[j] for j in J}

    # 5) Solve the interdiction problem.
    model, sSol, tSol = solve_r_facility_interdiction(I, J, w, N, r)
    return model, sSol, tSol


def convert_text_file_to_array(filename):
    """
    Reads the file and splits the contents into separate data blocks (trees).
    """
    with open(filename, "r") as file:
        content = file.read()

    tree_strings = [block for block in content.strip().split("\n\n") if block.strip()]
    return tree_strings


if __name__ == "__main__":
    # Read in the tree data from the text file.
    tree_str = convert_text_file_to_array("trees_500Total_vN_0.5F_p=0.5_hw.txt")
    startTime3 = timeit.default_timer()

    for i in range(len(tree_str)):
        model, sSol, tSol = solve_interdiction_from_data(tree_str[i])

        if model.SolCount > 0:
            #print("\n--- RESULTS ---")
            print(f"Optimal Obj (Uncovered Weight) = {model.ObjVal:.2f}")

            interdicted = [i for i in sSol if abs(sSol[i]) > 1e-6]
            #print("Facilities removed:", interdicted)

            covered = [j for j in tSol if abs(tSol[j]) > 1e-6]
            uncovered = [j for j in tSol if abs(tSol[j]) < 1e-6]

            #print("Covered customers   =", covered)
            #print("Uncovered customers =", uncovered)

    endTime3 = timeit.default_timer()
    print("Total run time:", endTime3 - startTime3)
