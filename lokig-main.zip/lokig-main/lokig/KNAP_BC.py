def knapsack_with_bucket_constraints(items, buckets, W):


    n = len(items)


    alpha = [-1] * n


    item_to_bucket = [0] * n
    for bucket_idx, (start, end) in enumerate(buckets):
        for i in range(start, end + 1):
            item_to_bucket[i] = bucket_idx
            if i == start:
                alpha[i] = buckets[bucket_idx - 1][1] if bucket_idx > 0 else -1
            else:
                alpha[i] = i - 1


    P = [[0] * (W + 1) for _ in range(n + 1)]


    for i in range(1, n + 1):
        w_i = items[i - 1][0]
        p_i = items[i - 1][1]
        alpha_i = alpha[i - 1]
        for j in range(W + 1):
            if w_i <= j:

                if alpha_i == -1:
                    profit_with_i = p_i
                else:
                    profit_with_i = P[alpha_i + 1][j - w_i] + p_i

                profit_without_i = P[i - 1][j]

                P[i][j] = max(profit_with_i, profit_without_i)
            else:

                P[i][j] = P[i - 1][j]


    max_profit = P[n][W]


    selected_items = []
    i, j = n, W
    while i > 0 and j >= 0:
        if P[i][j] != P[i - 1][j]:
            selected_items.append(i - 1)
            w_i = items[i - 1][0]
            alpha_i = alpha[i - 1]
            j -= w_i
            if alpha_i == -1:
                i = 0
            else:
                i = alpha_i + 1
        else:
            i -= 1

    selected_items.reverse()

    print(P)
    return max_profit, selected_items


if __name__ == "__main__":

    items = [
        (2, 3),
        (3, 6),
        (4, 10),
        (5, 6),
    ]


    buckets = [
        (0, 1),
        (2, 3),
    ]


    W = 5


    max_profit, selected_items = knapsack_with_bucket_constraints(items, buckets, W)


    print("MaxProfit:", max_profit)
    print("Items", selected_items)

