conda create -c defaults -c conda-forge -c gurobi -n lokig python=3.12 scipy numba cartopy networkx pydot gurobi pytest

# setting up Gurobi's licence:
# conda activate lokig
# grbgetkey KEY_ID_FROM_WEB_INTERFACE
# mv ~/gurobi.lic ~/.gurobi.lic
# echo "export GRB_LICENSE_FILE=~/.gurobi.lic" >> ~/.bashrc
